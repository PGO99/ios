//
//  ViewController.h
//  Calculador
//
//  Created by Juan Rodríguez on 04/10/19.
//  Copyright (c) 2019 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
    
    bool operatorPressed;
    bool add;
    NSString *firstEntry;
    NSString *secondEntry;
    
}

@property (strong, nonatomic) IBOutlet UILabel *labelOutput;



- (IBAction)numberPressed:(UIButton*)sender;

- (IBAction)clearPressed:(id)sender;
- (IBAction)addPressed:(id)sender;

- (IBAction)minusPressed:(id)sender;

- (IBAction)equalsPressed:(id)sender;


@end

