//
//  AppDelegate.h
//  Calculador
//
//  Created by Juan Rodríguez on 04/10/19.
//  Copyright (c) 2019 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
